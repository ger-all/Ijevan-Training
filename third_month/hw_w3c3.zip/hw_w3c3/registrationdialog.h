#ifndef REGISTRATIONDIALOG_H
#define REGISTRATIONDIALOG_H

#include <QDialog>
#include <map>

class QLineEdit;
class QLabel;

class RegistrationDialog : public QDialog
{
    Q_OBJECT

public:
    RegistrationDialog(std::map<QString, QString>& users, QWidget* parent = nullptr);

private slots:
    void onLineEditChanged(const QString& str);
    void onCreateButtonClicked();

private:
    std::map<QString, QString>& m_users;  // reference to mainwindow users
    QLineEdit* m_pUsername;
    QLineEdit* m_pPassword;
    QLabel* m_pMessage;
};

#endif // REGISTRATIONDIALOG_H
