#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <map>

class QLineEdit;
class QPushButton;
class QWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

private slots:
    void onLineEditChanged(const QString&);
    void onLoginButtonClicked();
    void onCreateButtonClicked();

// private:
//     void init();

private:
    QLineEdit* m_pUsername;
    QLineEdit* m_pPassword;
    QWidget *central;

    std::map<QString, QString> m_users;  // username -> password


};

#endif // MAINWINDOW_H
