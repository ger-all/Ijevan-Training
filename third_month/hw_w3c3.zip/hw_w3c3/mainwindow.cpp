#include "mainwindow.h"
#include "registrationdialog.h"

#include <QLineEdit>
#include <QRegularExpression>
#include <QRegularExpressionValidator>
#include <QVBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , m_pUsername(nullptr)
    , m_pPassword(nullptr)
{
    resize(300, 200);

    // Օրինակի համար մի քանի users
    m_users["john@mail.com"] = "A*1aaaaa";
    m_users["anna@mail.com"] = "B$2bbbbb";
    m_users["guest@mail.com"] = "C%3ccccc";

    // for Layout
    central = new QWidget(this);
    QVBoxLayout* layout = new QVBoxLayout(central);

    // for Icon
    QLabel *labelForPixmap = new QLabel(this);
    QPixmap pix(":/icon/images/login.png");
    QPixmap scaledPix = pix.scaled(80, 80, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    labelForPixmap->setPixmap(scaledPix);
    labelForPixmap->setAlignment(Qt::AlignCenter);

    // Username LineEdit
    m_pUsername = new QLineEdit(this);
    m_pUsername->setPlaceholderText("Username");

    /** ✓ example: a@a.ru
     * Minimum required։
     * _@_.__
     */
    QRegularExpression rx("^[\\w.-]+@[\\w.-]+\\.[A-Za-z]{2,}$");
    QRegularExpressionValidator* validator = new QRegularExpressionValidator(rx, this);
    m_pUsername->setValidator(validator);

    // Password LineEdit
    m_pPassword  = new QLineEdit(this);
    m_pPassword->setPlaceholderText("Password");
    m_pPassword->setEchoMode(QLineEdit::Password);

    /** ✓ example: A*1aaaaa
     * Minimum required։
     * length։                              8
     * uppercase letter:                    1
     * lowercase letter:                    1
     * digit:                               1
     * special character (@, $, !, %, *):   1
     */

    QRegularExpression rx2("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
    QRegularExpressionValidator* validator2 = new QRegularExpressionValidator(rx2, this);
    m_pPassword->setValidator(validator2);

    QPushButton* login = new QPushButton("Login");
    QPushButton* create = new QPushButton("Create account");

    layout->addWidget(labelForPixmap);
    layout->addWidget(m_pUsername);
    layout->addWidget(m_pPassword);
    layout->addWidget(login);
    layout->addWidget(create);

    central->setLayout(layout);
    setCentralWidget(central);

    connect(m_pUsername, &QLineEdit::textChanged, this, &MainWindow::onLineEditChanged);
    connect(m_pPassword, &QLineEdit::textChanged, this, &MainWindow::onLineEditChanged);

    connect(login, &QPushButton::clicked, this, &MainWindow::onLoginButtonClicked);
    connect(create, &QPushButton::clicked, this, &MainWindow::onCreateButtonClicked);
}


void MainWindow::onLineEditChanged(const QString& str) {
    QLineEdit* lineEdit = qobject_cast<QLineEdit*>(sender());  // dynamic_castից ավելի արագ է, ու խորհուրդ է տրվում
    if (!lineEdit) return;  // It's not necessary, but it's safe.

    // վերցնում ենք validator-ը, եթե կա
    const QValidator* validator = lineEdit->validator();
    if (!validator) return;

    QString input = str;
    int pos = 0;

    QValidator::State state = validator->validate(input, pos); // ::State is enum, and can have three values

    if (state == QValidator::Acceptable) {
        lineEdit->setToolTip("Valid email");
        lineEdit->setStyleSheet("QLineEdit { background-color: lightgreen; }");
    }
    else {
        lineEdit->setToolTip("Invalid email");
        lineEdit->setStyleSheet("QLineEdit { background-color: salmon; }");
    }
}


void MainWindow::onLoginButtonClicked() {
    QString username = m_pUsername->text();
    QString password = m_pPassword->text();

    QDialog dialog(this);
    dialog.resize(200, 100);
    QVBoxLayout *layout = new QVBoxLayout(&dialog);  // քանի որ տվել եմ parent, սա չեմ գրել՝ dialog.setLayout(layout);

    QLabel *lbl;

    auto it = m_users.find(username);
    if (it != m_users.end() && it->second == password) {
        dialog.setWindowTitle("Login Successful");
        lbl = new QLabel("Welcome, " + username + "\n\n✅ Login Successful", &dialog);
    }
    else {
        dialog.setWindowTitle("Login Failed");
        lbl = new QLabel("❌ Invalid username or password", &dialog);
    }

    layout->addWidget(lbl);
    dialog.exec();
}


void MainWindow::onCreateButtonClicked() {
    RegistrationDialog dialog(m_users);
    dialog.exec();
}
