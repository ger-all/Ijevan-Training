#include "registrationdialog.h"
#include <QVBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QRegularExpression>
#include <QRegularExpressionValidator>

RegistrationDialog::RegistrationDialog(std::unordered_map<QString, QString>& users, QWidget* parent)
    : QDialog(parent),
    m_users(users),
    m_pUsername(nullptr),
    m_pPassword(nullptr),
    m_pMessage(nullptr)
{
    setWindowTitle("Registration");
    resize(250, 150);

    // for Layout
    QVBoxLayout* layout = new QVBoxLayout(this);

    // for Icon
    QLabel *labelForPixmap = new QLabel(this);
    QPixmap pix(":/icon/images/registration.png");
    QPixmap scaledPix = pix.scaled(80, 80, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    labelForPixmap->setPixmap(scaledPix);
    labelForPixmap->setAlignment(Qt::AlignCenter); // center inside layout

    // Username LineEdit
    m_pUsername = new QLineEdit(this);
    m_pUsername->setPlaceholderText("Username");

    /** ✓ example: a@a.ru
     * Minimum required։
     * _@_.__
     */
    QRegularExpression rx("^[\\w.-]+@[\\w.-]+\\.[A-Za-z]{2,}$");
    QRegularExpressionValidator* validator = new QRegularExpressionValidator(rx, this);
    m_pUsername->setValidator(validator);

    // Password LineEdit

    m_pPassword = new QLineEdit(this);
    m_pPassword->setPlaceholderText("Password");
    m_pPassword->setEchoMode(QLineEdit::Password);  // for hide

    /** ✓ example: A*1aaaaa
     * Minimum required։
     * length։                              8
     * uppercase letter:                    1
     * lowercase letter:                    1
     * digit:                               1
     * special character (@, $, !, %, *):   1
     */

    QRegularExpression rx2("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
    QRegularExpressionValidator* validator2 = new QRegularExpressionValidator(rx2, this);
    m_pPassword->setValidator(validator2);

    QPushButton* create = new QPushButton("Create account");
    m_pMessage = new QLabel(this);

    layout->addWidget(labelForPixmap);
    layout->addWidget(m_pUsername);
    layout->addWidget(m_pPassword);
    layout->addWidget(create);
    layout->addWidget(m_pMessage);

    connect(m_pUsername, &QLineEdit::textChanged, this, &RegistrationDialog::onLineEditChanged);
    connect(m_pPassword, &QLineEdit::textChanged, this, &RegistrationDialog::onLineEditChanged);
    connect(create, &QPushButton::clicked, this, &RegistrationDialog::onCreateButtonClicked);
}

void RegistrationDialog::onLineEditChanged(const QString& str) {
    QLineEdit* lineEdit = qobject_cast<QLineEdit*>(sender());
    if (!lineEdit) return;

    const QValidator* validator = lineEdit->validator();
    if (!validator) return;

    QString input = str;
    int pos = 0;

    if (validator->validate(input, pos) == QValidator::Acceptable) {
        lineEdit->setStyleSheet("QLineEdit { background-color: lightgreen; }");
    } else {
        lineEdit->setStyleSheet("QLineEdit { background-color: salmon; }");
    }
}

void RegistrationDialog::onCreateButtonClicked() {
    QString u = m_pUsername->text();
    QString p = m_pPassword->text();

    int pos = 0;
    if (m_pUsername->validator()->validate(u, pos) != QValidator::Acceptable) {
        m_pMessage->setText("❌ Invalid username format");
        return;
    }

    if (m_pPassword->validator()->validate(p, pos) != QValidator::Acceptable) {
        m_pMessage->setText("❌ Invalid password format");
        return;
    }

    // Check username duplication
    if (m_users.find(u) != m_users.end()) {
        m_pMessage->setText("❌ User already exists");
        return;
    }

    // Add new user
    m_users[u] = p;
    m_pMessage->setText("✅ Account created successfully");
}
