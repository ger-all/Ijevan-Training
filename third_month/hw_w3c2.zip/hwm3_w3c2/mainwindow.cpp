#include "mainwindow.h"
// #include "ui_mainwindow.h"

#include <QPixmap>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    resize(400, 300);

    QWidget *central = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(central);

    layout->setContentsMargins(0,0,0,0);  // no margin around edges
    layout->setSpacing(0);         // no space between widgets

    // Label for text
    label = new QLabel("...", this);
    label->setFixedHeight(30);  // keep it small
    layout->addWidget(label);

    // Label for image
    QLabel *labelForPixmap = new QLabel(this);
    labelForPixmap->setScaledContents(true);  // pixmap follows label size
    labelForPixmap->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);

    QPixmap pix(":/img/img/my_image.png");
    QPixmap scaledPix = pix.scaled(15, 10, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    labelForPixmap->setPixmap(scaledPix);
    //

    // QPixmap pix(":/img/img/my_image.png");
    // labelForPixmap->setPixmap(pix);

    layout->addWidget(labelForPixmap);

    setCentralWidget(central);

    // ---- Dialog setup ----
    dialog = new QDialog(this);
    dialog->setWindowTitle("Dialog: write something");

    lineEdit = new QLineEdit(dialog);
    button = new QPushButton("Press Button", dialog);

    QVBoxLayout* dialogLayout = new QVBoxLayout(dialog);
    dialogLayout->addWidget(lineEdit);
    dialogLayout->addWidget(button);
    dialog->setLayout(dialogLayout);

    connect(button, &QPushButton::clicked, this, &MainWindow::onButtonClicked);

    dialog->exec(); // modal
}


void MainWindow::onButtonClicked() {
    label->setText(lineEdit->text());
    dialog->accept();
}
